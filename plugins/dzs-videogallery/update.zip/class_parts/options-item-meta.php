<?php



$this->options_item_meta = array(

    array(
        'name'=>'dzsvp_item_type',
        'type'=>'select',
        'select_type'=>'opener-listbuttons',
        'title'=>__("Type"),
        'sidenote'=>__("select the type of media"),
        'choices'=>array(
            array(
                'label'=>__("Self Hosted"),
                'value'=>'video',
            ),
            array(
                'label'=>__("youtube"),
                'value'=>'youtube',
            ),
            array(
                'label'=>__("vimeo"),
                'value'=>'vimeo',
            ),
            array(
                'label'=>__("inline"),
                'value'=>'inline',
            ),
        ),
        'choices_html'=>array(
            '<span class="option-con"><img src="'.$this->base_url.'admin/img/type_video.png"/><span class="option-label">'.__("Self Hosted").'</span></span>',
            '<span class="option-con"><img src="'.$this->base_url.'admin/img/type_youtube.png"/><span class="option-label">'.__("YouTube").'</span></span>',
            '<span class="option-con"><img src="'.$this->base_url.'admin/img/type_vimeo.png"/><span class="option-label">'.__("Vimeo").'</span></span>',
        ),


    ),



    array(
        'name'=>'dzsvp_thumb',
        'type'=>'attach',
        'title'=>__("Thumbnail"),
        'sidenote'=>__("This will replace the default wordpress thumbnail"),
        'extra_html_after_input'=>'<button style="display: inline-block; vertical-align: top;" class="refresh-main-thumb button-secondary">
                    Auto Generate
                </button>',
    ),

    array(
        'name'=>'dzsvp_extra_classes',
        'type'=>'text',
        'title'=>__("Extra Classes"),
        'sidenote'=>__("extra html classes applied to the player"),
    ),

    array(
        'name'=>'dzsvp_play_from',
        'type'=>'text',
        'title'=>__("Play From"),
        'sidenote'=>sprintf(__("play from a specific second, or input %slast%s to play from last position "),'<strong>','</strong>'),
    ),

    array(
        'name'=>'dzsvp_ad_array',
        'type'=>'text',
        'title'=>__("Manage Ads"),
        'sidenote'=>sprintf(__("construct an ad sequence ")),

        'extra_html_after_input'=>'<a class=" button-secondary quick-edit-adarray" href="#" style="cursor:pointer;">'.__("Edit Ads").'</a>',
    ),





    array(
        'name'=>'dzsvp_subtitle',
        'type'=>'attach',
        'title'=>__("Subtitle"),
        'sidenote'=>__("a optional subtitle file"),
        'extra_html_after_input'=>'',
    ),

);