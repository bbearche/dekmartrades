<?php
global $post, $wp_version;
$struct_uploader = '<div class="dzs-wordpress-uploader insert-id">
    <a href="#" class="button-secondary">' . __('Upload', 'dzsvp') . '</a>
</div>';
?>
<div class="select-hidden-con">
    <?php
    $lab_nonce = 'dzsap_meta_nonce';
    echo '<input type="hidden" name="'.$lab_nonce.'" value="'.wp_create_nonce($lab_nonce).'"/>';
    ?>



</div>



<?php

foreach ($this->options_item_meta as $lab => $oim){




    ?>
    <div class="setting <?php
    $option_name = $oim['name'];

    if($oim['type']=='attach'){
        ?>setting-upload<?php
    }

    ?>">
        <h5 class="setting-label"><?php echo $oim['title']; ?></h5>


        <?php

        if($oim['type']=='attach'){
            ?><span class="uploader-preview"></span><?php
        }

        ?>

        <?php

        $val = get_post_meta($post->ID, $option_name, true);

        $class = 'setting-field medium';

        if($oim['type']=='attach'){
            $class.=' uploader-target';
        }


        if($oim['type']=='attach') {
            echo DZSHelpers::generate_input_text($option_name, array(
                'class' => $class,
                'seekval' => $val,
            ));
        }
        if($oim['type']=='text') {
            echo DZSHelpers::generate_input_text($option_name, array(
                'class' => $class,
                'seekval' => $val,
            ));
        }
        if($oim['type']=='select') {


            $class = 'dzs-style-me skin-beige';

            if(isset($oim['select_type']) && $oim['select_type']){
                $class.=' '.$oim['select_type'];
            }

            echo DZSHelpers::generate_select($option_name, array(
                'class' => $class,
                'seekval' => $val,
                'options' => $oim['choices'],
            ));

            if(isset($oim['select_type']) && $oim['select_type']=='opener-listbuttons'){

                echo '<ul class="dzs-style-me-feeder">';

                foreach ($oim['choices_html'] as $oim_html){

                    echo '<li>';
                    echo $oim_html;
                    echo '</li>';
                }

                echo '</ul>';
            }


        }

        if($oim['type']=='attach') {
            echo $struct_uploader;
        }

        if(isset($oim['extra_html_after_input']) && $oim['extra_html_after_input']){
            echo $oim['extra_html_after_input'];
        }
        if(isset($oim['sidenote']) && $oim['sidenote']){
            echo '<div class="sidenote">'.$oim['sidenote'].'</div>';
        }

        ?>

    </div>

<?php



}
?>


