<?php
/*
  Plugin Name: DZS Video Gallery
  Plugin URI: http://digitalzoomstudio.net/
  Description: Creates and manages cool video galleries. Has a admin panel and tons of options and skins.
  Version: 9.35
  Author: Digital Zoom Studio
  Author URI: http://digitalzoomstudio.net/ 
 */



include_once(dirname(__FILE__).'/dzs_functions.php');
if(!class_exists('DZSVideoGallery')){
    include_once(dirname(__FILE__).'/class-dzsvg.php');
}


define("DZSVG_VERSION", "9.35");

$dzsvg = new DZSVideoGallery();

if (file_exists('widget.php')) {
    include_once('widget.php');
}


if(isset($_GET['dzsvg_show_generator_export_slider']) && $_GET['dzsvg_show_generator_export_slider']=='on'){
    $dzsvg->show_generator_export_slider();
    die();
}

//$dzsvg->is_preview=true;