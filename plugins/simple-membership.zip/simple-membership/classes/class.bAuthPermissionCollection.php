<?php
/**
 * Description of BAuthPermissionCollection
 *
 * @author nur
 */
class BAuthPermissionCollection extends BPermissionCollection{
//put your code here
}
